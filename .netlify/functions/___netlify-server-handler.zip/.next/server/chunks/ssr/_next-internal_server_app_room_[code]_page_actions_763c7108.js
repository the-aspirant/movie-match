module.exports=[11783,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_room_%5Bcode%5D_page_actions_763c7108.js.map